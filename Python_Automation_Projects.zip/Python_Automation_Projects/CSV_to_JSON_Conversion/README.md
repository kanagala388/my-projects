# CSV_to_JSON_Conversion.

## Folder Struture
	
	Input : A folder contains Input CSV file
	Processed: A folder contains Ouput Json file
	Convertor.py : Main Python file
	README.md : A Readme file.

## Execution

	1. Place a CSV file in the Input folder.
	2. Run the Convertor.py
		$ python3 Convertor.py
	3. Check the output Json file in the processed folder.
	
	Note: Make sure that Convertor.py has executable permissions.
	
